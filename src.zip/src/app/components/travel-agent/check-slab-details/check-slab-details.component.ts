import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-check-slab-details',
  templateUrl: './check-slab-details.component.html',
  styleUrls: ['./check-slab-details.component.css']
})
export class CheckSlabDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
