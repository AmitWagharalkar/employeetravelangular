import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Login } from 'src/app/domain/login';

@Component({
  selector: 'app-travel-agent-page',
  templateUrl: './travel-agent-page.component.html',
  styleUrls: ['./travel-agent-page.component.css']
})
export class TravelAgentPageComponent implements OnInit {
   login:Login=new Login();
   base:string="";

  constructor(private router:Router) { }

  ngOnInit(): void {
    this.login = JSON.parse(sessionStorage.getItem('login') || '{}');
    this.base="Welcome  "+ this.login.userId+"..!";
  }
  logout(){
    this.router.navigate(['login'])
  }
  viewUpcomingRequest(){
    this.router.navigate(['viewupcomingtravelrequest'])
  }

  bookingDetails(){
    this.router.navigate(['bookingdetails']);
  }

}
