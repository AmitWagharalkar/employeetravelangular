import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Login } from 'src/app/domain/login';

@Component({
  selector: 'app-project-manager-page',
  templateUrl: './project-manager-page.component.html',
  styleUrls: ['./project-manager-page.component.css']
})
export class ProjectManagerPageComponent implements OnInit {
  base:string="";
  login:Login=new Login();
  constructor(private router:Router) { }

  ngOnInit(): void {
    this.login = JSON.parse(sessionStorage.getItem('login') || '{}');
    this.base="Welcome  "+ this.login.userId+"..!";
  }
  logout(){
    this.router.navigate(['login'])
  }
  viewTravelRequest(){
    this.router.navigate(['viewtravelrequest']);
  }
  addRequestPage(){
    this.router.navigate(['addrequestpage'])
  }
  viewExistingRequest(){
    this.router.navigate(['viewexistingrequest'])
  }

}
