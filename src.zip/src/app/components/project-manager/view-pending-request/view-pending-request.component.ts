import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-pending-request',
  templateUrl: './view-pending-request.component.html',
  styleUrls: ['./view-pending-request.component.css']
})
export class ViewPendingRequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
